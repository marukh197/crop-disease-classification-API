import matplotlib.pyplot as plt
import seaborn as sns
import base64
from io import BytesIO


def generate_class_distribution_plot(class_distribution):
    plt.figure(figsize=(10, 5))
    sns.barplot(x=list(class_distribution.keys()), y=list(class_distribution.values()))
    plt.xticks(rotation=45)
    plt.xlabel('Classes')
    plt.ylabel('Number of Images')
    plt.title('Class Distribution')
    plt.tight_layout()

    # Save plot to a BytesIO object and encode to base64
    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode('utf8')
    plt.close()

    return f"data:image/png;base64,{plot_url}"
