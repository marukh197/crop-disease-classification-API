import os
import logging
import numpy as np
from PIL import Image, ImageEnhance


# Function to augment images
def augment_image(image_path, target_dir, num_augmentations=1):
    """Augments an image and saves the augmented images to the target directory."""
    image = Image.open(image_path)
    
    for i in range(num_augmentations):
        # Create a copy of the original image for augmentation
        augmented_image = image.copy()

        # Randomly apply augmentations
        # 1. Rotation
        angle = np.random.choice([0, 90, 180, 270])
        augmented_image = augmented_image.rotate(angle)

        # 2. Flipping
        if np.random.rand() > 0.5:
            augmented_image = augmented_image.transpose(Image.FLIP_LEFT_RIGHT)  # Horizontal flip
        if np.random.rand() > 0.5:
            augmented_image = augmented_image.transpose(Image.FLIP_TOP_BOTTOM)  # Vertical flip

        # 3. Brightness Adjustment
        if np.random.rand() > 0.5:
            brightness_factor = np.random.uniform(0.5, 1.5)  # Random brightness factor
            enhancer = ImageEnhance.Brightness(augmented_image)
            augmented_image = enhancer.enhance(brightness_factor)

        # 4. Contrast Adjustment
        if np.random.rand() > 0.5:
            contrast_factor = np.random.uniform(0.5, 1.5)  # Random contrast factor
            enhancer = ImageEnhance.Contrast(augmented_image)
            augmented_image = enhancer.enhance(contrast_factor)

        # 5. Color Adjustment
        if np.random.rand() > 0.5:
            color_factor = np.random.uniform(0.5, 1.5)  # Random color factor
            enhancer = ImageEnhance.Color(augmented_image)
            augmented_image = enhancer.enhance(color_factor)

        # 6. Random Crop (optional)
        if np.random.rand() > 0.5:
            width, height = augmented_image.size
            left = np.random.randint(0, width // 4)
            top = np.random.randint(0, height // 4)
            right = width - np.random.randint(0, width // 4)
            bottom = height - np.random.randint(0, height // 4)
            augmented_image = augmented_image.crop((left, top, right, bottom))

            # Resize back to original dimensions (optional)
            augmented_image = augmented_image.resize(image.size)

        # Save the augmented image
        base_name = os.path.basename(image_path)
        augmented_image_path = os.path.join(target_dir, f"aug_{i}_{base_name}")
        augmented_image.save(augmented_image_path)

        logging.info(f"Saved augmented image: {augmented_image_path}")