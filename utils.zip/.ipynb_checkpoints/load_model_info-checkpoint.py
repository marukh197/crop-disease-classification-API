
from werkzeug.utils import secure_filename 
import logging
import os

def load_model_info(model_choice, model_type):
    # Construct the path to the model's text file based on the model type
    txt_path = os.path.join('models', model_type, model_choice.replace('.h5', '.txt').replace('.keras', '.txt'))
    class_labels = []

    logging.info(f"Loading class labels from: {txt_path}")

    # Check if the file exists
    if not os.path.exists(txt_path):
        logging.error(f"File not found: {txt_path}")
        return []

    try:
        with open(txt_path, 'r') as file:
            # Read each line from the file
            for line in file:
                logging.debug(f"Reading line: {line.strip()}")

                # Look for the line that starts with 'Classes:'
                if line.startswith("Classes:"):
                    # Extract the part after 'Classes:'
                    class_list = line.split("Classes:")[1].strip()

                    # Log the extracted class list for debugging
                    logging.info(f"Extracted class list: {class_list}")

                    # Ensure the class list has the correct format with brackets
                    if class_list.startswith("[") and class_list.endswith("]"):
                        # Remove the brackets and split the content into class names
                        class_labels = [label.strip().strip("'") for label in class_list[1:-1].split(",")]

                        # Log the final list of class labels
                        logging.info(f"Processed class labels: {class_labels}")
                    else:
                        # Log an error if the format is incorrect
                        logging.error(f"Class list format is incorrect: {class_list}")
                        return []

                    # Return the parsed class labels
                    return class_labels

            logging.error("No 'Classes:' line found in the file.")
            return []

    except Exception as e:
        logging.error(f"Error loading class labels: {e}")
        return []
