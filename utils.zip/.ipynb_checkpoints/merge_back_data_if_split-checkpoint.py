import os
import shutil
import logging

def merge_back_data_if_split(dataset_path):
    # Check if the dataset has been split into train/validation/test
    split_dirs = ['train', 'validation', 'test']
    
    if all(os.path.exists(os.path.join(dataset_path, split_dir)) for split_dir in split_dirs):
        # Iterate through each split (train, validation, test)
        for split_dir in split_dirs:
            split_dir_path = os.path.join(dataset_path, split_dir)
            
            # Loop through each class inside the split directory
            for class_name in os.listdir(split_dir_path):
                class_split_dir = os.path.join(split_dir_path, class_name)
                
                # Check if it is a directory (class folder)
                if os.path.isdir(class_split_dir):
                    # Create or merge the class folder in the main dataset directory
                    class_main_dir = os.path.join(dataset_path, class_name)
                    os.makedirs(class_main_dir, exist_ok=True)
                    
                    # Move only image files back to the main directory, ignore subdirectories
                    for img in os.listdir(class_split_dir):
                        img_path = os.path.join(class_split_dir, img)
                        if os.path.isfile(img_path):  # Move only files (images)
                            shutil.move(img_path, os.path.join(class_main_dir, img))
                    
                    # After moving images, check if the class directory is empty and remove it
                    if not os.listdir(class_split_dir):
                        os.rmdir(class_split_dir)
            
            # Remove the entire split directory after merging all class folders
            shutil.rmtree(split_dir_path)

        logging.info("Data merged back successfully.")
    else:
        logging.warning("No train, validation, and test directories found for merging.")
