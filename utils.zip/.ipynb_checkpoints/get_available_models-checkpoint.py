import os 
def get_available_models(model_type):
    if model_type == 'pest':
        model_folder = 'models/Pest'
    elif model_type == 'crop':
        model_folder = 'models/crop'
    else:
        return []  # Return an empty list for invalid model types

    # Check if the model folder exists
    if not os.path.exists(model_folder):
        return []

    # List all model files ending with .h5 or .keras
    models = [f for f in os.listdir(model_folder) if f.endswith('.h5') or f.endswith('.keras')]
    return models