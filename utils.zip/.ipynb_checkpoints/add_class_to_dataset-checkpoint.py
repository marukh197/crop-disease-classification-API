
import os
import shutil
import logging

# Step 1: Add class to dataset (Updated)
def add_class_to_dataset(dataset_dir, class_name, class_images_dir):
    class_path = os.path.join(dataset_dir, class_name)
    os.makedirs(class_path, exist_ok=True)

    if not os.path.exists(class_images_dir):
        logging.error(f"Class images directory '{class_images_dir}' does not exist.")
        return f"Class images directory '{class_images_dir}' does not exist."
    
    for img in os.listdir(class_images_dir):
        img_path = os.path.join(class_images_dir, img)
        dest_path = os.path.join(class_path, img)
        logging.info(f"Copying from {img_path} to {dest_path}")

        if os.path.isfile(img_path):
            try:
                shutil.copy(img_path, dest_path)
            except Exception as e:
                logging.error(f"Failed to copy {img_path} to {dest_path}. Error: {str(e)}")
        else:
            logging.error(f"{img_path} is not a valid file.")
    
    logging.info(f"Class '{class_name}' added successfully!")
    return f"Class '{class_name}' added successfully!"
