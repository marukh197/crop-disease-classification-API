
import os

def get_class_distribution(dataset_path):
    class_distribution = {}
    
    # Iterate through the dataset directory
    for class_name in os.listdir(dataset_path):
        class_path = os.path.join(dataset_path, class_name)
        
        # Check if it's a directory and not the 'models' folder
        if os.path.isdir(class_path) and class_name != 'models':
            image_count = len([f for f in os.listdir(class_path) if os.path.isfile(os.path.join(class_path, f))])
            class_distribution[class_name] = image_count
            
    return class_distribution