import os
import shutil
import logging


# Step 2: Remove class from dataset
def remove_class_from_dataset(dataset_dir, class_name):
    class_path = os.path.join(dataset_dir, class_name)
    try:
        if os.path.exists(class_path):
            shutil.rmtree(class_path)  # Remove the class directory and all its contents
            logging.info(f"Class '{class_name}' removed successfully!")
            return f"Class '{class_name}' removed successfully!"
        else:
            logging.warning(f"Class '{class_name}' does not exist.")
            return f"Class '{class_name}' does not exist."
    except Exception as e:
        logging.error(f"Error removing class '{class_name}': {str(e)}")
        return f"An error occurred while trying to remove class '{class_name}': {str(e)}"