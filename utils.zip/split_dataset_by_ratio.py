import os
import shutil
import logging
import numpy as np

def split_dataset_by_ratio(dataset_path, train_ratio, val_ratio, test_ratio):
    # Ensure the sum of ratios equals 1
    assert train_ratio + val_ratio + test_ratio == 1, "Ratios must sum to 1"

    # Create directories for train, validation, and test sets if they do not exist
    for split in ['train', 'validation', 'test']:
        os.makedirs(os.path.join(dataset_path, split), exist_ok=True)

    # Go through each class (subdirectory)
    class_dirs = [d for d in os.listdir(dataset_path) if os.path.isdir(os.path.join(dataset_path, d)) and d not in ['train', 'validation', 'test', 'models']]

    for class_dir in class_dirs:
        class_path = os.path.join(dataset_path, class_dir)
        
        # Recursively get images from the subdirectories of each class
        images = []
        for root, dirs, files in os.walk(class_path):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):  # Adjust image extensions as needed
                    images.append(os.path.join(root, file))
        
        # If there are no images in the class folder or subfolders, skip it
        if not images:
            logging.warning(f"No images found in class directory: {class_path}")
            continue
        
        np.random.shuffle(images)  # Shuffle images for random selection

        # Calculate the number of images for each split
        total_images = len(images)
        train_count = int(total_images * train_ratio)
        val_count = int(total_images * val_ratio)

        # Split images into train, validation, and test
        train_images = images[:train_count]
        val_images = images[train_count:train_count + val_count]
        test_images = images[train_count + val_count:]

        # Create directories for this class in the respective splits
        for split in ['train', 'validation', 'test']:
            split_dir = os.path.join(dataset_path, split, class_dir)
            os.makedirs(split_dir, exist_ok=True)

        # Move images to their respective directories
        for img in train_images:
            img_name = os.path.basename(img)
            shutil.move(img, os.path.join(dataset_path, 'train', class_dir, img_name))
        for img in val_images:
            img_name = os.path.basename(img)
            shutil.move(img, os.path.join(dataset_path, 'validation', class_dir, img_name))
        for img in test_images:
            img_name = os.path.basename(img)
            shutil.move(img, os.path.join(dataset_path, 'test', class_dir, img_name))

        # Optionally: Remove empty subdirectories after moving the images
        for root, dirs, _ in os.walk(class_path, topdown=False):
            for dir in dirs:
                dir_path = os.path.join(root, dir)
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)  # Remove empty directory

    logging.info("Dataset splitting completed successfully!")
