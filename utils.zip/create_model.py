import tensorflow as tf
from tensorflow.keras.applications import ResNet50, DenseNet201
from tensorflow.keras.applications import ConvNeXtBase 
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, GlobalAveragePooling2D, Dense, Dropout
from tensorflow.keras.models import Sequential
from utils.focal_loss import focal_loss

img_height = 224
img_width = 224


def create_model(base_model_name, num_classes):
    if base_model_name == "ResNet50":
        base_model = tf.keras.applications.ResNet50(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
    elif base_model_name == "DenseNet201":
        base_model = tf.keras.applications.DenseNet201(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
    elif base_model_name == "ConvNeXt":
        base_model = tf.keras.applications.ConvNeXt(weights='imagenet', include_top=False, input_shape=(img_height, img_width, 3))
    else:
        raise ValueError("Invalid model name")

    # Add new layers on top
    x = base_model.output
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dense(1024, activation='relu')(x)
    predictions = tf.keras.layers.Dense(num_classes, activation='softmax')(x)

    model = tf.keras.models.Model(inputs=base_model.input, outputs=predictions)

    # Compile the model
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model
